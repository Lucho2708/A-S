
<h2> contacto del sitio </h2>
<p>Nombre: {{ $datos->nome}}</p>
<p>Correo Electronico: {{ $datos->email}}</p>
<p>Asunto: {{ $datos->subject}}</p>
<p>Mensaje: {{ $datos->message}}</p>
 
