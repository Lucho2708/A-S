
<h2> contacto del sitio </h2>
<p>Nombre: <?php echo e($datos->nome); ?></p>
<p>Correo Electronico: <?php echo e($datos->email); ?></p>
<p>Asunto: <?php echo e($datos->subject); ?></p>
<p>Mensaje: <?php echo e($datos->message); ?></p>
 
