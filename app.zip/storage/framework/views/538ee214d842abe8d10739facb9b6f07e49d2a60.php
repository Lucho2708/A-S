?php
<h2> contato do site</h2>
<p>Nome: <?php echo e($datos->nome); ?></p>
<p>E-mail: <?php echo e($datos->email); ?></p>
<p>message: <?php echo e($datos->message); ?></p>
 
 ?>